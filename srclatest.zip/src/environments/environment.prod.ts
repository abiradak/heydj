export const environment = {
  production: true,
  apiUrl: 'https://xug5l9nwo4.execute-api.ap-south-1.amazonaws.com/dev',
};
