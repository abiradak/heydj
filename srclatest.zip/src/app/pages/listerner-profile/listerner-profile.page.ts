import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listerner-profile',
  templateUrl: './listerner-profile.page.html',
  styleUrls: ['./listerner-profile.page.scss'],
})
export class ListernerProfilePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
