import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dj-profile',
  templateUrl: './dj-profile.page.html',
  styleUrls: ['./dj-profile.page.scss'],
})
export class DjProfilePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
